Supporting Fig 1: Receptive field mapping

Plotting data for Supp Fig 1A-1D are fields in 'rfValsLFP_M1' and 'rfValsLFP_M2'

Supp Fig 1A:
maxValsByElectrode: magnitude of evoked response by mapping stimuli, across different electrodes. The (row,column) coordinate of each data point indicates the location of the corresponding electrode in the grid.

Supp Fig 1B:
elecsCount plotted against responseValue as a histogram

Supp Fig 1D:
Scatter plot of RF centers of the high response electrodes (highRespElecsRFCenterAzi, highRespElecsRFCenterEle)

Supp Fig 1E:
RF center for high response electrodes in M1:
Based on LFP: (M1_aziC_LFP, M1_eleC_LFP)
Based on spikes: (M1_aziC_spike, M1_eleC_spike)
Similarly for M2.

Supp Fig 1F:
RF size pair for LFP and spike based estimation in M1: (size_M1_LFP, size_M1_spike)
Their mean value is also shown (meanRFSize_LFP_M1, meanRFSize_Spikes_M1)
Similarly for M2.

