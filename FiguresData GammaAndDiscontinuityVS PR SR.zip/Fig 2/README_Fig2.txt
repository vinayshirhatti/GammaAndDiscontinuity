Fig 2: Effect of annular discontinuity at different locations

Fig 2A, 2B:
commonElecsGammaNorm and commonElecsFRNorm are normalized gamma and firing rate values for all center electrodes for 4 inner radii and 5 widths of annular discontinuity.
The mean (meanNormGamma, meanNormFR) and s.e.m (semNormGamma, semNormFR) from these data are plotted in Fig 2A and 2B.

Fig 2C:
'slopesGamma' and 'slopesFR' give the slope values for regression of normalized gamma and firing rates on 5 widths of annular discontinuity for 4 inner radii. Values are given for the center electrodes in M1 and M2.
The corresponding mean and s.e.m are calculated and plotted in Fig 2C.