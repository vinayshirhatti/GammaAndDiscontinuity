This folder contains data from a manuscript under review in PLoS Biology

Folder for each figure has MATLAB (.mat) data files that can be processed and replotted to make the figures in the paper. 