Fig 1: Effect of annular discontinuity

Fig 1A:
Fig1A_TFData_SingleElec_M1, Fig1A_TFData_Population_M1 and Fig1A_TFData_Population_M2: Data for row 1, 2 and 3 respectively of Fig 1A.
Each file contains values for the time and frequency axes, and an array called ‘diffTFSpectra’ that gives the difference spectra for the 5 annulus widths.

Fig1B:
allElecsPSDdB_M1/M2: Mean PSD across trials for each annulus width for all center electrodes across sessions in M1 and M2.
The plotted graphs (meanPSDAll) are computed as mean of these, and semPSDAll is the corresponding standard error of mean (calculated as s.e.m(X) = std(X)/sqrt(number of elements in X)).
freqVals: frequency values (i.e. x-axis)

Fig 1C:
allElecsPSTH_M1/M2: Mean PSTH (firing rates) across trials for each annulus width for all center electrodes across sessions in M1 and M2.
The plotted graphs (meanPSTHAll) are computed as mean of these, and semPSTHAll is the corresponding standard error of mean.
FRxs: time values (i.e. x-axis)

Fig 1D:
commonElecsGammaNorm and commonElecsFRNorm are normalized gamma and firing rate values during stimulus period for all common center electrodes (from 1B and 1C).
The mean (meanNormGamma, meanNormFR) and s.e.m (semNormGamma, semNormFR) from these data are plotted in Fig 1D.

Fig 1E:
'slopesGamma' and 'slopesFR' give the regression slope values for normalized gamma and firing rates respectively in M1 and M2, for all corresponding common center electrodes (from 1B and 1C).
Their absolute values are plotted in the scatter plot in Fig 1E and their means are also shown.

The values (not just magnitude) in 'slopesGamma' and 'slopesFR' are plotted in Supporting Figure 2A.