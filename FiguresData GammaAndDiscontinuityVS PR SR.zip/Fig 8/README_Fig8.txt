Fig 8: Effect of stimulus discontinuity in the model

Fig 8A, 8B and 8C:
E response (responseE), I response (responseI), peak power (peakPower) and peak frequency (peakFrequency) computed from the model for different inputs to E and I (allInputsE, allInputsI) are given.

sizeRegimeBoundary: coordinates within which increase in input to I causes oscillations to increase in magnitude and become slower in frequency.

eInput and iInput are the example inputs used to illustrate model behavior in Fig 8D and 8E.

Fig 8D:
E response (eResponse) and its mean value (eMeanResponse) for the example inputs and three model weights (corresponding to 8A, 8B and 8C). 
timeVals: time values 

Fig 8E:
E and I nullclines (eNullcline, iNullcline) and trajectories (trajectoryEI, plotted against xVals) corresponding to the three cases.
