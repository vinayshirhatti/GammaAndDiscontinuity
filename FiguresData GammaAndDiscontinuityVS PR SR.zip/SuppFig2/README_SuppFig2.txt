Supporting Fig 2: Slope of regression of gamma and firing rate with spatial, orientation and phase discontinuity

Data for Supporting Fig 2A, 2B and 2C are included in the data for Fig 1E, Fig 3E and Fig 4E respectively. Please check the related notes and data.

