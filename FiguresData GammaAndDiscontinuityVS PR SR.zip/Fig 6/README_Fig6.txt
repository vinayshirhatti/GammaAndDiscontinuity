Fig 6: Effect of contrast discontinuity on gamma and firing responses

Fig 6A, 6B:
commonElecsGammaNorm and commonElecsFRNorm are normalized gamma and firing rate values during stimulus period for different inner and outer contrast of the stimuli, for all center electrodes in M1 and M2.
Their mean values (meanNormGamma, meanNormFR) are plotted in Fig 6A and 6B top row for both M1 and M2.

The bottom row plots the mean change in the normalized gamma (6A) or firing rates (6B) from a continuous stimulus to the nearest discontinuity.
These values for all center electrodes are given in:
allCenterContrastDecreaseGammaNorm, allSurroundContrastDecreaseGammaNorm, allCenterContrastIncreaseGammaNorm and allSurroundContrastIncreaseGammaNorm
The mean values and s.e.m. calculated from these are plotted in the bottom row.
The values for firing responses are given in the Fig6B_.. file.

Fig 6C:
The values from 6A and 6B for the continuous stimulus case with 50% and 75% contrast in M1 and M2 respectively are shown in the scatter plot in 6C. The mean values are also shown.


