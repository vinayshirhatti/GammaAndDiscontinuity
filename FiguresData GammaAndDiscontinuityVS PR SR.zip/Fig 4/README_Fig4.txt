Fig 4: Effect of phase discontinuity

Data format same as Fig 1, except that the stimulus conditions are as per phase discontinuity.

The values (not just magnitude) in 'slopesGamma' and 'slopesFR' in 'Fig4E_GammaAndFR_RegSlopes_M1M2.mat' are plotted in Supporting Figure 2C.