Fig 5: Effect of contrast discontinuity

Data format same as Fig 1A and 1B, except that the stimulus conditions are as per contrast discontinuity.