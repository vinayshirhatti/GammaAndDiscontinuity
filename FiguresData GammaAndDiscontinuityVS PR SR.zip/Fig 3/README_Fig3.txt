Fig 3: Effect of orientation discontinuity

Data format same as Fig 1, except that the stimulus conditions are as per orientation discontinuity.

The values (not just magnitude) in 'slopesGamma' and 'slopesFR' in 'Fig3E_GammaAndFR_RegSlopes_M1M2.mat' are plotted in Supporting Figure 2B.