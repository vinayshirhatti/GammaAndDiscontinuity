Fig 5: Effect of annular discontinuity at different locations, TF difference spectra and PSD

Data format same as Fig 1A and 1B, except that the stimulus conditions are as per annular discontinuity at 4 different inner radii from the center.